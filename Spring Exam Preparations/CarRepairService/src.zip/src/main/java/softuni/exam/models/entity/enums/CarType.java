package softuni.exam.models.entity.enums;

public enum CarType {
    SUV, coupe, sport
}
