package softuni.exam.util;

public interface ValidationUtil {

    public <E> boolean isValid(E entity);
}
