package softuni.exam.models.entity.enums;

public enum StarType {
    RED_GIANT, WHITE_DWARF, NEUTRON_STAR
}
