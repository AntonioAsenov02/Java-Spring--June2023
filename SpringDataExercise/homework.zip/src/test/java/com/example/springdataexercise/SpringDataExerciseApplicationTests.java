package com.example.springdataexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
