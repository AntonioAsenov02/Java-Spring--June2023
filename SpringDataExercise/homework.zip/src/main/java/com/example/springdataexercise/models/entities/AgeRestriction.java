package com.example.springdataexercise.models.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
