package com.example.springdataexercise.models.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
