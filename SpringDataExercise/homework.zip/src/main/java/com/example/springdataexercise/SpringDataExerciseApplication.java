package com.example.springdataexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataExerciseApplication.class, args);


    }
}
